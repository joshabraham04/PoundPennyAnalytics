import React from "react";
import './Almost.css'

function Almost(){
    return (
        <div className = 'almost'>
          <h1 className='header'>Almost there!</h1>
          <p className='para'>Please check your e-mail and confirm your new account. Prepare for a whole new world of financial literacy and freedom.</p>
        </div>
      );
}
export default Almost;
