import React from "react";
import './Construction.css';

function Construction(){
    return(
        <div className="construction">
            <header>
                Excuse the dust! We're under construction!
            </header>
        </div>
    );

}
export default Construction;